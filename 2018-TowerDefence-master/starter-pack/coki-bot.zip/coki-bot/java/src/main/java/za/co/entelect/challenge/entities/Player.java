package za.co.entelect.challenge.entities;

import za.co.entelect.challenge.enums.PlayerType;

public class Player {
    public PlayerType playerType;
    public int energy;
    public int health;
    public int hitsTaken;
    public int score;
}
